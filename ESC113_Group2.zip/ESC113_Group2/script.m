clc; clear; close all;
%% This section defines and plots the function f(λ) = sin(λ) - λ*cos(λ) to estimate where it crosses zero (i.e., eigenvalues).

% Define the function for eigenvalue equation
f = @(lambda) sin(lambda) - lambda .* cos(lambda);

% Define lambda range
lambda = linspace(-10, 10, 1000);

% Evaluate the function
y = f(lambda);

% Plot the function
figure;
plot(lambda, y, 'b', 'LineWidth', 2);
hold on;
yline(0, 'k--'); % Zero line for reference
xlabel('\lambda');
ylabel('f(\lambda)');
title('Eigenvalue Equation sin(\lambda) - \lambda cos(\lambda) = 0');
grid on;
hold off;

% Estimate the first root by inspecting the plot
disp('Estimate the first root (λ1) from the graph.');

%% Use Newton’s method to accurately compute the first root
% Starting from an initial guess, this section iteratively applies Newton-Raphson to find the first positive eigenvalue.
clc; clear;

% Define function and derivative
f = @(lambda) sin(lambda) - lambda .* cos(lambda);
df = @(lambda) lambda .* sin(lambda);

% Initial guess (from part (a))
lambda_n = 4; % Approximate root from graph

% Newton’s Method
tol = 1e-6;
max_iter = 100;
for i = 1:max_iter
    lambda_next = lambda_n - f(lambda_n) / df(lambda_n);
    if abs(lambda_next - lambda_n) < tol
        break;
    end
    lambda_n = lambda_next;
end

% Display result
disp(['First positive eigenvalue λ1 = ', num2str(lambda_n)]);


%% Compute the first 10 eigenvalues using Newton’s method
% Using the spacing between roots, this section finds 10 eigenvalues and visualizes their locations and spacing.
clc; clear;

% Define function and derivative
f = @(lambda) sin(lambda) - lambda .* cos(lambda);
df = @(lambda) lambda .* sin(lambda);

% Initialize variables
n_roots = 10;
lambdas = zeros(n_roots, 1);
lambda_n = 4; % Initial guess

for n = 1:n_roots
    % Newton's method
    for i = 1:100
        lambda_next = lambda_n - f(lambda_n) / df(lambda_n);
        if abs(lambda_next - lambda_n) < 1e-6
            break;
        end
        lambda_n = lambda_next;
    end
    lambdas(n) = lambda_n;
    
    % Update initial guess for next root
    lambda_n = lambda_n + pi; % Approximate next root
end

% Display first 10 roots
disp('First 10 eigenvalues:');
disp(lambdas(1:10));

lambda = linspace(0, lambdas(end), 1000);
y = f(lambda);
%Plot the eigen function and eigen values
figure;
plot(lambda, y, 'b', 'LineWidth', 2);
hold on;
xlabel('\lambda');
ylabel('f(\lambda)');
title('Eigenvalue Equation: sin(\lambda) - \lambda cos(\lambda) = 0');
grid on;
scatter(lambdas,0,'r*','LineWidth',2);
yline(0, 'k--'); % Zero line for reference
legend("eigenvalue equation","eigenvalues");
hold off;


% Plot spacing of eigenvalues
n_values = 1:n_roots-1;
spacing = diff(lambdas);
figure;
plot(n_values, spacing, 'o-');
xlabel('n');
ylabel('Spacing \lambda_{n+1} - \lambda_n');
title('Spacing of Eigenvalues');
grid on;


%% Compute and plot the time evolution of concentration profile c(x,t)
% Using the eigenvalues, this section calculates c(x,t) at multiple time points and visualizes the evolution of the profile over space.

% Part (d): Plot c(x,t)
eigenvalues = lambdas;
x_range = linspace(0, 1, 100); % Spatial range
t_values = [0.0005, 0.01, 0.05, 0.07, 0.2]; % Time values

num_eigenvalues = length(eigenvalues); % Use previously computed eigenvalues

c_xt_all_t = zeros(length(x_range), length(t_values)); % Initialize solution matrix

for t_idx = 1:length(t_values)
    t = t_values(t_idx);
    c_xt = zeros(size(x_range)); % Initialize c(x,t)
    
    for x_idx = 1:length(x_range)
        x = x_range(x_idx);
        
        sum_series = 0;
        for n = 1:num_eigenvalues
            lambda_n = eigenvalues(n);
            c_n = (4 * (1 - cos(lambda_n))) / (2 * lambda_n - sin(2 * lambda_n));
            sum_series = sum_series + c_n * sin(lambda_n * x) * exp(-lambda_n^2 * t);
        end
        
        c_xt(x_idx) = (3/2)*x + sum_series; % Compute c(x,t)
    end
    
    c_xt_all_t(:, t_idx) = c_xt; % Store result for current time
end

% Plot results for each time value
figure;
for t_idx = 1:length(t_values)
    plot(x_range, c_xt_all_t(:, t_idx), 'LineWidth', 1.5);
    hold on;
end

xlabel('x');
ylabel('c(x,t)');
title('Concentration Profile c(x,t)');
legend(arrayfun(@(t)sprintf('t=%.4f', t), t_values, 'UniformOutput', false));
grid on;
